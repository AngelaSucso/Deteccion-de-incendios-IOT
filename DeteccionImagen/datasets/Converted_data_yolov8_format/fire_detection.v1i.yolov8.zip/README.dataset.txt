# fire_detection > 2024-04-30 1:19pm
https://universe.roboflow.com/yusufozen/fire_detection-yiy75

Provided by a Roboflow user
License: CC BY 4.0

